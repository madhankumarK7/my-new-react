import axios from 'axios';

const axiosInstance = axios.create({
    baseURL: 'http://localhost:8000/api', // Use Vite environment variables
});

export default axiosInstance;