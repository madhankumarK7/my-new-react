<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CreateDeadLock extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:create-dead-lock';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->ask('Ready to create a dummy table123?');

        DB::statement('CREATE TABLE `table123` ( `id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(255) NOT NULL, `marks` INT NOT NULL, PRIMARY KEY (`id`) ) ENGINE=InnoDB;');

        DB::statement('INSERT INTO table123 (id, name, marks) VALUES (1, "abc", 5);');

        DB::statement('INSERT INTO table123 (id, name, marks) VALUES (2, "xyz", 1);');

        $this->info('Created table123 to test deadlock.');

        $this->ask('Would you like to begin?');

        DB::statement('begin;');
        DB::statement('UPDATE table123 SET marks=marks-1 WHERE id=1;');

        $this->info('Open a MySQL connection, switch to this database, and paste the following:');

        $this->info('BEGIN;');
        $this->info('UPDATE table123 SET marks=marks+1 WHERE id=2;');
        $this->info('UPDATE table123 SET marks=marks-1 WHERE id=1;');
        $this->info('COMMIT;');

        $this->ask('Are you ready to test the deadlock?');

        DB::statement('UPDATE table123 SET marks=marks+1 WHERE id=2;');
        DB::statement('COMMIT;');

        $this->info('Open the laravel.log file and confirm a deadlock was retried.');

        $this->ask('Ready to drop the test123 table?');

        DB::statement('DROP TABLE table123;');        
    }
}
